/** @type {import('next').NextConfig} */
const nextConfig = {
  // App directory is now stable, no need for experimental flag
}

module.exports = nextConfig
